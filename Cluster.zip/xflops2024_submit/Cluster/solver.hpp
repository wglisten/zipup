#pragma once
#include <vector>
#include <iostream>
#include <algorithm>

struct Server {
    long long weight, capacity;
    Server(long long w, long long c) : weight(w), capacity(c) {}
    Server(){}
};

long long solve(Server *servers, long long n) {
    // Sort servers based on their capacity minus weight
    std::sort(servers, servers + n, [](const Server &a, const Server &b) {
        return a.capacity - a.weight > b.capacity - b.weight;
    });

    long long max_risk = 0;
    long long current_load = 0;

    // Calculate the maximum risk
    for (int i = 0; i < n; ++i) {
        current_load += servers[i].weight;
        max_risk = std::max(max_risk, current_load - servers[i].capacity);
    }

    return max_risk;

}
